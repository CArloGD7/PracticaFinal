/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Persistencia;

import Excepciones.ExcepcionArchivo;
import Modelo.Sospechoso;
import java.util.List;

/**
 *
 * @author JAIRO
 */
public interface ISospechosoDao {
    
    void insertarSospechoso(Sospechoso p)throws ExcepcionArchivo;
    List<Sospechoso> leerSospechoso()throws ExcepcionArchivo;
    Sospechoso buscarSospechoso(Sospechoso p)throws ExcepcionArchivo;
    Sospechoso eliminarSospechoso(Sospechoso p)throws ExcepcionArchivo;
    
}
