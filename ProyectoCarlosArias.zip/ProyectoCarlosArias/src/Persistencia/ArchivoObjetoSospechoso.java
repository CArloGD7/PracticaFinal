package Persistencia;

import Excepciones.ExcepcionArchivo;
import Modelo.Sospechoso;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StreamCorruptedException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ArchivoObjetoSospechoso implements ISospechosoDao {

    private File archivo;
    private FileInputStream modoLectura;
    private FileOutputStream modoEscritura;

    public ArchivoObjetoSospechoso() {
        this("Sospechoso.bin");
    }

    public ArchivoObjetoSospechoso(String path) {
        this.archivo = new File(path);
    }

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public FileInputStream getModoLectura() {
        return modoLectura;
    }

    public void setModoLectura(FileInputStream modoLectura) {
        this.modoLectura = modoLectura;
    }

    public FileOutputStream getModoEscritura() {
        return modoEscritura;
    }

    public void setModoEscritura(FileOutputStream modoEscritura) {
        this.modoEscritura = modoEscritura;
    }

    
    private void guardarArchivo(List<Sospechoso> lista) throws ExcepcionArchivo, FileNotFoundException, IOException {
        try {
            this.modoEscritura = new FileOutputStream(this.archivo);
            try (ObjectOutputStream oos = new ObjectOutputStream(this.modoEscritura)) {
                oos.writeObject(lista);
            }

        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("Erro al abrir archivo de objetos, no existe");
        } catch (SecurityException e) {
            throw new ExcepcionArchivo("No tiene acceso para el archivo en modo escritura");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivo("EL manejador de archivo en escritura en Null");
        } catch (IOException e) {
            throw new ExcepcionArchivo("Error al escribir en el archivo");
        }

    }

    private List<Sospechoso> leerArchivo() throws ExcepcionArchivo {
        
        ObjectInputStream ois = null;
        if(!this.archivo.exists()){
            return new ArrayList<Sospechoso>();
        }
        
        try {
            this.modoLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.modoLectura);
            List<Sospechoso> lista = (List<Sospechoso>)ois.readObject();
            ois.close();
            return lista;

        } catch (FileNotFoundException e) {
            throw new ExcepcionArchivo("Erro al abrir archivo de objetos en modo lectura , no existe");
        } catch (SecurityException e) {
            throw new ExcepcionArchivo("No tiene acceso para el archivo en modo lectura");
        } catch (StreamCorruptedException e) {
            throw new ExcepcionArchivo("Error con el flujo de datos de cabecera del objeto");
        } catch (NullPointerException e) {
            throw new ExcepcionArchivo("EL manejador de archivo en lectura en Null");
        } catch (IOException e) {
            throw new ExcepcionArchivo("Error al leer en el archivo");
        }
        catch(ClassNotFoundException e){
            throw new ExcepcionArchivo("Error, el objeto leido del archivo no tiene clase definida");
        }

    }
    @Override
    public void insertarSospechoso(Sospechoso p) throws ExcepcionArchivo {
        List<Sospechoso> lista = this.leerArchivo();
        lista.add(p);
        try {
            this.guardarArchivo(lista);
        } catch (IOException ex) {
            Logger.getLogger(ArchivoObjetoSospechoso.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<Sospechoso> leerSospechoso() throws ExcepcionArchivo {
            return this.leerArchivo();
    }

    
    
    @Override
    public Sospechoso buscarSospechoso(Sospechoso p) throws ExcepcionArchivo {
          List<Sospechoso> lista = this.leerArchivo();
          for(Sospechoso b: lista){
              if(b.getId()==(p.getId())){
                  return b;
              }
          }
          return null;    }

    @Override
    public Sospechoso eliminarSospechoso(Sospechoso p) throws ExcepcionArchivo {
        List<Sospechoso> lista = this.leerArchivo();
        Iterator<Sospechoso>i = lista.iterator();
        Sospechoso eliminado=null;
        while(i.hasNext()){
            Sospechoso leido = i.next();
            if(leido.getId()==(p.getId())){
                eliminado = leido;
                i.remove();
            }
        }
        try {
            this.guardarArchivo(lista);
        } catch (IOException ex) {
            Logger.getLogger(ArchivoObjetoSospechoso.class.getName()).log(Level.SEVERE, null, ex);
        }
        return eliminado;    }


}
