/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Excepciones.ExcepcionArchivo;
import Modelo.Caso;
import Modelo.Cibercrimen;
import Modelo.Detective;
import Modelo.Homicidio;
import Modelo.ListaCaso;
import Modelo.ListaDetective;
import Modelo.Narcotico;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author carlo
 */
public class GuiCaso extends javax.swing.JFrame {
    
    DefaultTableModel Td = new DefaultTableModel();
    ListaCaso modelo;
    List<Caso> Lista;
    private Scanner modoLectura;
    
    public GuiCaso() {
        initComponents();
        cambiarValores();
        this.setLocationRelativeTo(null);
        String[] titulo = new String[]{"CASO", "NUMERO", "DESCRIPCION", "CODIGO", "DETECTIVE", "NOMBRE CLAVE", "TIPO"};
        Td.setColumnIdentifiers(titulo);
        TblDec.setModel(Td);
        this.modelo = new ListaCaso();
        actualizarTabla();
        this.setLocationRelativeTo(this);
        
    }
    
    public void cambiarValores() {
        if (this.cmbTipo.getSelectedItem() == "CIBERCRIMEN") {
            txtTipo.setText("TIPO:");
            cmbTip.removeAllItems();
            cmbTip.addItem("Robo de identidad"); //robo de identidad, robo de información, fraudes por internet
            cmbTip.addItem("Robo de información");
            cmbTip.addItem("Rraudes por internet");
        }else if (this.cmbTipo.getSelectedItem() == "HOMICIDIO") {
            txtTipo.setText("2 DETECTIVE:");
            cmbTip.removeAllItems();
        }else if (this.cmbTipo.getSelectedItem() == "NARCOTICO") {//caso local, estatal o federal. 
            txtTipo.setText("TIPO:");
            cmbTip.removeAllItems();
            cmbTip.addItem("Caso Local");
            cmbTip.addItem("Caso Estatal");
            cmbTip.addItem("Caso Federal");
        }
        
    }
    
    public void actualizarTabla() {
        try {
            this.Lista = this.modelo.leerCaso();
        } catch (ExcepcionArchivo ex) {
            Logger.getLogger(GuiDetective.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.Td.setNumRows(0);
        for (Caso p : this.Lista) {
            this.modoLectura = new Scanner(p.getDataFileFormat());
            while (this.modoLectura.hasNext()) {
                String datos[] = this.modoLectura.nextLine().split(";");
                this.Td.addRow(datos);
                
            }
            
        }
    }
    
    private void limpiarCampos() {
        this.txtDetective.setText(null);
        this.txtNumero.setText(null);
        this.txtDescripcion.setText(null);
        this.txtNomclave.setText(null);
        
    }

    /*private void asginarCampos() {
        int numero = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 1);
        String Descripcion =(String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 2);
        String codigo = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 3);
        int detective = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 4);
        String nomclave = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 5);
        String tipo = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 6);
        String Detective2 =(String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 7);
        this.cmbCodigo.setText(id);
        this.txtNumero.setText(Nom);
        this.txtDescripcion.setText(Ape);
        this.txtNomclave.setText(Exp);

    }*/
    private void guardarDatos() {
        try {
            Caso c = this.leerDatos();
            this.modelo.insertarCaso(c);
            
        } catch (ExcepcionArchivo e) {
            JOptionPane.showMessageDialog(null, "Error", "Eror", JOptionPane.WARNING_MESSAGE);
            
        }
        
    }
//int numero, String descripcion, String codigo, int idDetective, String nombreClave

    private Caso leerDatos() {
        int numero = Integer.valueOf(this.txtNumero.getText());
        String Descripcion = this.txtDescripcion.getText();
        String codigo = (String) this.cmbCodigo.getSelectedItem();
        int detective = Integer.valueOf(this.txtDetective.getText());
        String nomclave = this.txtNomclave.getText();
        String tipo = (String) this.cmbTip.getSelectedItem();
        String Detective2 = (String) this.cmbTip.getSelectedItem();
        
        if (this.cmbTipo.getSelectedItem() == "CIBERCRIMEN") {
            
            return new Cibercrimen(numero, Descripcion, codigo, detective, nomclave, tipo);//int numero, String descripcion, String codigo, int idDetective, String nombreClave, String Tipo

        } else if (this.cmbTipo.getSelectedItem() == "HOMICIDIO") {
            
            return new Homicidio(numero, Descripcion, codigo, detective, nomclave, Detective2);//int numero, String descripcion, String codigo, int idDetective, String nombreClave, String Tipo

        } else if (this.cmbTipo.getSelectedItem() == "NARCOTICO") {
            
            return new Narcotico(numero, Descripcion, codigo, detective, nomclave, tipo);//int numero, String descripcion, String codigo, int idDetective, String nombreClave, String Tipo
        }
        
        return null;
    }
    
    private void eliminarDato() {
        String idEliminado = (String) this.Td.getValueAt(this.TblDec.getSelectedRow(), 1);
        int id = Integer.valueOf(idEliminado);
        try {
            Caso eliminado = this.modelo.eliminarCaso(new Cibercrimen(id));
            this.actualizarTabla();
        } catch (ExcepcionArchivo e) {
            
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        FONDO = new javax.swing.JPanel();
        txtNumero = new javax.swing.JTextField();
        txtDescripcion = new javax.swing.JTextField();
        txtNomclave = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TblDec = new javax.swing.JTable();
        txtDetective = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        cmbTipo = new javax.swing.JComboBox<>();
        txtTipo = new javax.swing.JLabel();
        cmbTip = new javax.swing.JComboBox<>();
        cmbCodigo = new javax.swing.JComboBox<>();
        jButton5 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Detective");

        FONDO.setBackground(new java.awt.Color(204, 204, 204));
        FONDO.setMaximumSize(new java.awt.Dimension(720, 400));
        FONDO.setRequestFocusEnabled(false);
        FONDO.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtNumero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumeroActionPerformed(evt);
            }
        });
        txtNumero.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtNumeroKeyTyped(evt);
            }
        });
        FONDO.add(txtNumero, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 180, 160, -1));

        txtDescripcion.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDescripcionKeyTyped(evt);
            }
        });
        FONDO.add(txtDescripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 210, 160, -1));
        FONDO.add(txtNomclave, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 300, 160, -1));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/folderblack_93099_1.png"))); // NOI18N
        FONDO.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 40, -1, -1));

        jButton1.setText("Agregar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        FONDO.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 370, -1, -1));

        jButton2.setText("Editar");
        FONDO.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 370, -1, -1));

        jButton3.setText("Eliminar");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        FONDO.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 370, -1, -1));

        jLabel7.setFont(new java.awt.Font("Roboto Black", 1, 36)); // NOI18N
        jLabel7.setText("CasoCerrado");
        FONDO.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 10, -1, -1));

        jLabel1.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel1.setText("NUMERO:");
        FONDO.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, -1, -1));

        jLabel2.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel2.setText("DESCRIPCION:");
        FONDO.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, -1, 20));

        jLabel3.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel3.setText("CODIGO:");
        FONDO.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 250, -1, -1));

        jLabel4.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel4.setText("ID DETECTIVE:");
        FONDO.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 280, -1, -1));

        jLabel5.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel5.setText("NOMBRE CLAVE:");
        FONDO.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 300, -1, 20));

        jButton4.setFont(new java.awt.Font("Roboto Black", 1, 12)); // NOI18N
        jButton4.setText("<");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        FONDO.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 450, 50, 30));

        TblDec.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        TblDec.setEditingColumn(0);
        TblDec.setEditingRow(0);
        jScrollPane2.setViewportView(TblDec);

        FONDO.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 60, 730, 410));

        txtDetective.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDetectiveActionPerformed(evt);
            }
        });
        txtDetective.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDetectiveKeyTyped(evt);
            }
        });
        FONDO.add(txtDetective, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 270, 160, -1));

        jLabel8.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        jLabel8.setText("TIPO DE CASO:");
        FONDO.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, -1, -1));

        cmbTipo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "CIBERCRIMEN", "HOMICIDIO", "NARCOTICO" }));
        cmbTipo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbTipoActionPerformed(evt);
            }
        });
        FONDO.add(cmbTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 150, 160, -1));

        txtTipo.setFont(new java.awt.Font("Roboto Light", 1, 14)); // NOI18N
        txtTipo.setText("jLabel9");
        FONDO.add(txtTipo, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 330, -1, 20));

        cmbTip.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cmbTip.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbTipActionPerformed(evt);
            }
        });
        FONDO.add(cmbTip, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 330, 160, -1));

        cmbCodigo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "A", "B", "C" }));
        FONDO.add(cmbCodigo, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 240, 160, -1));

        jButton5.setText("Agregar Sospechosos");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        FONDO.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 410, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(FONDO, javax.swing.GroupLayout.DEFAULT_SIZE, 1083, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(FONDO, javax.swing.GroupLayout.DEFAULT_SIZE, 522, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNumeroKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtNumeroKeyTyped
        // TODO add your handling code here:
        char validar = evt.getKeyChar();
        
        if (Character.isLetter(validar)) {
            getToolkit().beep();
            evt.consume();
        }

    }//GEN-LAST:event_txtNumeroKeyTyped

    private void txtDescripcionKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDescripcionKeyTyped
        char validar = evt.getKeyChar();
        
        if (Character.isDigit(validar)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtDescripcionKeyTyped

    private void txtNumeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumeroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumeroActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        Principal b = new Principal();
        b.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        this.guardarDatos();
        this.actualizarTabla();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void cmbTipoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTipoActionPerformed
        cambiarValores();
    }//GEN-LAST:event_cmbTipoActionPerformed

    private void cmbTipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbTipActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbTipActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        eliminarDato();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void txtDetectiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDetectiveActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDetectiveActionPerformed

    private void txtDetectiveKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDetectiveKeyTyped
        char validar = evt.getKeyChar();
        
        if (Character.isLetter(validar)) {
            getToolkit().beep();
            evt.consume();
        }
    }//GEN-LAST:event_txtDetectiveKeyTyped

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        GuiSospechosos b = new GuiSospechosos();
        b.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_jButton5ActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel FONDO;
    private javax.swing.JTable TblDec;
    private javax.swing.JComboBox<String> cmbCodigo;
    private javax.swing.JComboBox<String> cmbTip;
    private javax.swing.JComboBox<String> cmbTipo;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField txtDescripcion;
    private javax.swing.JTextField txtDetective;
    private javax.swing.JTextField txtNomclave;
    private javax.swing.JTextField txtNumero;
    private javax.swing.JLabel txtTipo;
    // End of variables declaration//GEN-END:variables
}
