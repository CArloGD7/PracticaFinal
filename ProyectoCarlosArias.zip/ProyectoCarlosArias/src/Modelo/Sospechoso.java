package Modelo;

import java.io.Serializable;

public class Sospechoso implements Serializable{

    private int id;
    private String nombre;
    private String alias;
    private int edad;
    private String Nvivienda;
    private String Localidad;
    private String Ciudad;
    private String Departamento;
    private String Pais;
    private String Descripcion;

    public Sospechoso(int id, String nombre, String alias, int edad, String Nvivienda, String Localidad, String Ciudad, String Departamento, String Pais, String Descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.alias = alias;
        this.edad = edad;
        this.Nvivienda = Nvivienda;
        this.Localidad = Localidad;
        this.Ciudad = Ciudad;
        this.Departamento = Departamento;
        this.Pais = Pais;
        this.Descripcion = Descripcion;
    }

    public Sospechoso(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getNvivienda() {
        return Nvivienda;
    }

    public void setNvivienda(String Nvivienda) {
        this.Nvivienda = Nvivienda;
    }

    public String getLocalidad() {
        return Localidad;
    }

    public void setLocalidad(String Localidad) {
        this.Localidad = Localidad;
    }

    public String getCiudad() {
        return Ciudad;
    }

    public void setCiudad(String Ciudad) {
        this.Ciudad = Ciudad;
    }

    public String getDepartamento() {
        return Departamento;
    }

    public void setDepartamento(String Departamento) {
        this.Departamento = Departamento;
    }

    public String getPais() {
        return Pais;
    }

    public void setPais(String Pais) {
        this.Pais = Pais;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

    public String getDataFileFormat() {
        return this.id + ";" + this.nombre + ";" + this.alias + ";" + this.edad + ";" + this.Nvivienda + ";" + this.Localidad + ";" + this.Ciudad + ";" + this.Departamento + ";" + this.Pais + ";" + this.Descripcion;

    }
}
