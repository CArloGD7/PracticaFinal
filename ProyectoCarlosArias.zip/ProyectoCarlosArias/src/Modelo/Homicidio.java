package Modelo;

public class Homicidio extends Caso {
    private String Detective2;

    public Homicidio(int numero, String descripcion, String codigo, int idDetective, String nombreClave, String Detective2) {
        super(numero, descripcion, codigo, idDetective, nombreClave);
        this.Detective2=Detective2;
    }

    public String getDetective2() {
        return Detective2;
    }

    public void setDetective2(String tipo) {
        this.Detective2= tipo;
    }
    

    @Override
    public String getDataFileFormat() {
        return "Homicidio;" + this.getNumero() + ";" + this.getDescripcion() + ";" + this.getCodigo() + ";" + this.getIdDetective() + ";" + this.getNombreClave() + ";" + "" +this.getDetective2();
    }
    
}
