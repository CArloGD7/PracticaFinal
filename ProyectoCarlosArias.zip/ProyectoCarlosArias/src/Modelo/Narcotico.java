package Modelo;

public class Narcotico extends Caso{
    private String tipo;

    public Narcotico(int numero, String descripcion, String codigo, int idDetective, String nombreClave, String tipo) {
        super(numero, descripcion, codigo, idDetective, nombreClave);
        this.tipo = tipo;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    

    @Override
    public String getDataFileFormat() {
        return "Narotico;" + this.getNumero() + ";" + this.getDescripcion() + ";" + this.getCodigo() + ";" + this.getIdDetective() + ";" + this.getNombreClave() + ";" + this.getTipo()+";" + "";
    }
    
    
    
}
