package Modelo;

import java.io.Serializable;

public class Detective implements Serializable {

    private int id;
    private String nombre;
    private String apellido;
    private int experiencia;
    private String caso;

    public Oficina oficina;

    public Detective(int id, String nombre, String apellido, int experiencia, String caso) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.experiencia = experiencia;
        this.caso = caso;
    }

    public Detective(int id) {
        this.id = id;
    }
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getExperiencia() {
        return experiencia;
    }

    public void setExperiencia(int experiencia) {
        this.experiencia = experiencia;
    }

    public String getCaso() {
        return caso;
    }

    public void setCaso(String caso) {
        this.caso = caso;
    }

    public String getDataFileFormat() {
        return this.id + ";" + this.nombre + ";" + this.apellido + ";" + this.experiencia + ";" + this.caso;

    }

}
