/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package co.edu.unicesar.persistencia;

import co.edu.unicesar.excepciones.ExcepcionArchivo;
import co.edu.unicesar.modelo.Publicacion;
import java.util.List;

/**
 *
 * @author JAIRO
 */
public interface IPublicacionDao {
    
    void insertarPublicacion(Publicacion p)throws ExcepcionArchivo;
    List<Publicacion> leerPublicaciones()throws ExcepcionArchivo;
    Publicacion buscarPublicacion(Publicacion p)throws ExcepcionArchivo;
    Publicacion eliminarPublicacion(Publicacion p)throws ExcepcionArchivo;
    List<Publicacion> filtrar(String idbn) throws ExcepcionArchivo;
    
}
