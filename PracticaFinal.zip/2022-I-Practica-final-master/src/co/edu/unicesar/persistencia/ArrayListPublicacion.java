/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicesar.persistencia;

import co.edu.unicesar.excepciones.ExcepcionArchivo;
import co.edu.unicesar.modelo.Publicacion;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author JAIRO
 */
public class ArrayListPublicacion implements IPublicacionDao {
    private final List<Publicacion> listaPublicacion;

    public ArrayListPublicacion() {
        this.listaPublicacion = new ArrayList();
    }
    
    
    @Override
    public void insertarPublicacion(Publicacion p) {
        this.listaPublicacion.add(p);
    }

    @Override
    public List<Publicacion> leerPublicaciones() {
       List<Publicacion> lista = new ArrayList(this.listaPublicacion);
       return lista;
    }

    @Override
    public Publicacion buscarPublicacion(Publicacion p) {
        Publicacion buscar=null;
        for(Publicacion i: this.listaPublicacion){
            if(i.getIdbn().equalsIgnoreCase(p.getIdbn())){
                buscar = i;
                break;
            }
        }
        return buscar;
        
    }

    @Override
    public Publicacion eliminarPublicacion(Publicacion p) {
        Iterator<Publicacion> i = this.listaPublicacion.iterator();
        Publicacion eliminado=null;
        while(i.hasNext()){
            Publicacion aux = i.next();
            if(aux.getIdbn().equalsIgnoreCase(p.getIdbn())){
                eliminado = aux;
                i.remove();
                break;
            }
        }
        return eliminado;
    }

    @Override
    public List<Publicacion> filtrar(String idbn) throws ExcepcionArchivo {
        List<Publicacion> lista = this.leerPublicaciones();
        List<Publicacion> listaFiltrada = new ArrayList();
        for(Publicacion a: lista){
            String idbnLista = a.getIdbn();
            String idbnFiltrada = String.valueOf(idbn);
            if(idbnLista.contains(idbnFiltrada)){
                listaFiltrada.add(a);
            }
            
        }
        return listaFiltrada;    }
    
}
