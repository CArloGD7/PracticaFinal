package co.edu.unicesar.persistencia;

import co.edu.unicesar.excepciones.ExcepcionArchivo;
import co.edu.unicesar.modelo.AudioLibro;
import co.edu.unicesar.modelo.Libro;
import co.edu.unicesar.modelo.Publicacion;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ImpArchivoTexto implements IPublicacionDao {

    private int pag;
    private int edi;
    private double pes;
    private double dur;
    private File archivo;
    private FileWriter modoEscritura;
    private Scanner modoLectura;

    public ImpArchivoTexto() {
        this("Publicacion.Libro");
    }

    public ImpArchivoTexto(String ruta) {
        this.archivo = new File(ruta);
    }

    public File getArchivo() {
        return archivo;
    }

    public void setArchivo(File archivo) {
        this.archivo = archivo;
    }

    public FileWriter getModoEscritura() {
        return modoEscritura;
    }

    public void setModoEscritura(FileWriter modoEscritura) {
        this.modoEscritura = modoEscritura;
    }

    public Scanner getModoLectura() {
        return modoLectura;
    }

    public void setModoLectura(Scanner modoLectura) {
        this.modoLectura = modoLectura;
    }

    @Override
    public void insertarPublicacion(Publicacion p) {
        PrintWriter pw = null;
        try {
            this.modoEscritura = new FileWriter(archivo, true);
            pw = new PrintWriter(this.modoEscritura);
            pw.println(p.getDataFileFormat());

        } catch (IOException ioe) {

        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }
//"A;" + this.idbn + ";" + this.titulo + ";" + this.autor + ";" + this.anio + ";" + this.costo + ";" + 2323 +";" + 2323 + ";" ";" + this.peso + ";" + this.duracion + ";" + this.formato;

    private Publicacion cargarDatos(String[] data) {   //String idbn, String titulo, String autor, int anio, double costo
        String tipo = (data[0]);
        String idbn = (data[1]);
        String titulo = (data[2]);
        String autor = (data[3]);
        int anio = Integer.valueOf(data[4]);
        double costo = Double.valueOf(data[5]);

        if (!"".equals(data[6])) {
            pag = Integer.valueOf(data[6]);
        }

        int npag = pag;

        if (!"".equals(data[7])) {
            edi = Integer.valueOf(data[7]);
        }
        
        int edicion = edi;
        
        if (!"".equals(data[8])) {
            pes = Double.valueOf(data[8]);
        }
        if (!"".equals(data[9])) {
            dur = Double.valueOf(data[9]);
        }

        double peso = pes;
        double duracion = dur;
        String formato = (data[10]);

        if ("L".equals(tipo)) {
            return new Libro(npag, edicion, idbn, titulo, autor, anio, costo);
        }

        if ("A".equals(tipo)) {
            return new AudioLibro(duracion, peso, formato, idbn, titulo, autor, anio, costo);//double duracion, double peso, String formato, String idbn, String titulo, String autor, int anio, double costo
        }
        return null;

    }

    @Override
    public List<Publicacion> leerPublicaciones() throws ExcepcionArchivo {
        List<Publicacion> lista;
        try {
            this.modoLectura = new Scanner(this.archivo);
            lista = new ArrayList();
            while (this.modoLectura.hasNext()) {
                String datos[] = this.modoLectura.nextLine().split(";");
                Publicacion c = this.cargarDatos(datos);
                lista.add(c);
            }
            return lista;

        } catch (FileNotFoundException ioe) {
            throw new ExcepcionArchivo("Error al abrir archivo en modo lectura, no existe");
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }

    }

    @Override
    public Publicacion buscarPublicacion(Publicacion p) throws ExcepcionArchivo {
        Publicacion buscado = null;
        try {
            this.modoLectura = new Scanner(this.archivo);
            while (this.modoLectura.hasNext()) {
                String datos[] = this.modoLectura.nextLine().split(";");
                Publicacion aux = this.cargarDatos(datos);
                if (aux.getIdbn().equals(p.getIdbn())) {
                    buscado = aux;
                    break;
                }
            }
            return buscado;

        } catch (FileNotFoundException ioe) {
            throw new ExcepcionArchivo("Error al abrir archivo en modo lectura, no existe");
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }
    }

    private void renombrarArchivo(File tmp) throws IOException {
        if (!tmp.exists()) {
            throw new IOException("El archivo temporal no existe");
        }

        if (!this.archivo.delete()) {
            tmp.delete();
            throw new IOException("No es posible eliminar el archivo original");
        }

        if (!tmp.renameTo(this.archivo)) {
            throw new IOException("No es posible renombrar el archivo temporal");
        }
    }

    @Override
    public Publicacion eliminarPublicacion(Publicacion p) throws ExcepcionArchivo {
        Publicacion eliminado = null;
        ImpArchivoTexto archivoTmp = new ImpArchivoTexto("Publicacion.tmp");
        try {
            this.modoLectura = new Scanner(this.archivo);
            while (this.modoLectura.hasNext()) {
                String datos[] = this.modoLectura.nextLine().split(";");
                Publicacion aux = this.cargarDatos(datos);
                if (aux.getIdbn().equals(p.getIdbn())) {
                    eliminado = aux;
                } else {
                    archivoTmp.insertarPublicacion(aux);
                }
            }
            this.modoLectura.close();
            this.renombrarArchivo(archivoTmp.archivo);
            return eliminado;

        } catch (FileNotFoundException ioe) {
            throw new ExcepcionArchivo("Error al abrir archivo en modo lectura, no existe");
        } catch (IOException e) {
            throw new ExcepcionArchivo(e.getMessage());
        } finally {
            if (this.modoLectura != null) {
                this.modoLectura.close();
            }
        }
    }

    @Override
    public List<Publicacion> filtrar(String idbn) throws ExcepcionArchivo {
        List<Publicacion> lista = this.leerPublicaciones();
        List<Publicacion> listaFiltrada = new ArrayList();
        for (Publicacion a : lista) {
            String idbnLista = a.getIdbn();
            String idbnFiltrada = String.valueOf(idbn);
            if (idbnLista.contains(idbnFiltrada)) {
                listaFiltrada.add(a);
            }

        }
        return listaFiltrada;
    }

}
