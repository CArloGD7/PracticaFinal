package co.edu.unicesar.vista;

import javax.swing.JDialog;
import javax.swing.JOptionPane;

public class Mensaje {
    public static void mostrar(JDialog ventana, String titulo, String msg, int icono){
        JOptionPane.showMessageDialog(ventana, msg, titulo, icono);
    }
}
