/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicesar.vista;

import co.edu.unicesar.excepciones.ExcepcionArchivo;
import java.awt.HeadlessException;
import javax.swing.JOptionPane;

public class Opcion {
    public Opcion(){
            boolean salir = false;
        int opcion;
        do {
            try {
                while (!salir) {
                    opcion = Integer.parseInt(JOptionPane.showInputDialog("Elija una opcion\n" + " 1. Consola\n" + " 2. InterfazGrafica\n" + " 3. Salir"));

                    switch (opcion) {
                        case 1:
                            new VistaConsola().run();
                            break;
                        case 2:
                            new TipoDePersistencia().setVisible(true);
                            salir = true;
                            break;
                        case 3:
                            salir = true;
                            break;
                        default:
                            JOptionPane.showMessageDialog(null, "Ingrese un numero entre 1 y 3", "Mensaje en la barra de titulo", JOptionPane.WARNING_MESSAGE);
                    }

                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Ingrese un numero entre 1 y 3", "Mensaje en la barra de titulo", JOptionPane.WARNING_MESSAGE);

            }
        } while (!salir);
        
    }


}
