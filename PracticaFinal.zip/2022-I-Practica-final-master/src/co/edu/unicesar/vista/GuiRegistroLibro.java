package co.edu.unicesar.vista;

import co.edu.unicesar.excepciones.ExcepcionArchivo;
import co.edu.unicesar.modelo.Libro;
import co.edu.unicesar.modelo.ListaPublicacion;
import co.edu.unicesar.modelo.Publicacion;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import static java.lang.String.valueOf;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
// this.idbn + ";" + this.titulo + ";" + this.autor + ";" + this.anio + ";" + this.costo + ";" + this.nPaginas + ";" + this.edicion

public class GuiRegistroLibro extends JDialog implements ActionListener {

    private JPanel panelPrincipal, panelDatos, panelOpciones;
    private JButton btnNuevo, brnguardar, btnCancelar;
    private JLabel lbIdbn, lbTitulo, lbAutor, lbAnio, lbCosto, lbNpaginas, lbEdicion;
    private JTextField txtIdbn, txtTitulo,txtAutor,txtAnio;
    private JFormattedTextField txtCosto, txtNpaginas,txtEdicion;

    private Container contenedor;

    private ListaPublicacion modelo;

    public GuiRegistroLibro(Frame frame, boolean bln, int Op) {
        super(frame, bln);
        this.modelo = new ListaPublicacion(Op);
        this.setTitle("Registro de Libros - Version 1.0");
        this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        this.iniciarComponentes();
        //this.setSize(300, 200);
        this.pack();
        this.setLocationRelativeTo(null);
        this.setVisible(true);
    }

    private void iniciarComponentes() {
        this.contenedor = this.getContentPane();
        this.contenedor.setLayout(new FlowLayout());

        this.panelPrincipal = new JPanel();
        this.panelPrincipal.setLayout(new BorderLayout());

        this.iniciarPanelDatos();
        this.iniciarPanelOpciones();

        this.panelPrincipal.setBorder(BorderFactory.createTitledBorder("Datos Libro"));

        this.contenedor.add(this.panelPrincipal);

    }

    private void iniciarPanelDatos() {

        this.panelDatos = new JPanel();
        this.panelDatos.setLayout(new GridLayout(7, 2, 5, 5));

        this.lbIdbn = new JLabel("Idbn: ");
        this.lbTitulo = new JLabel("Titulo: ");
        this.lbAutor = new JLabel("Autor: ");
        this.lbAnio = new JLabel("Año: ");
        this.lbCosto = new JLabel("Costo $: ");
        this.lbNpaginas = new JLabel("N Paginas: ");
        this.lbEdicion = new JLabel("Edicion: ");

        this.txtIdbn = new JTextField(15);
        this.txtTitulo = new JTextField(15);
        this.txtAutor = new JTextField(15);
        this.txtAnio = new JTextField(15);
        this.txtCosto = new JFormattedTextField(new Integer(0));
        this.txtNpaginas = new JFormattedTextField(new Integer(0));
        this.txtEdicion = new JFormattedTextField(0);

        this.panelDatos.add(this.lbIdbn);
        this.panelDatos.add(this.txtIdbn);

        this.panelDatos.add(this.lbTitulo);
        this.panelDatos.add(this.txtTitulo);

        this.panelDatos.add(this.lbAutor);
        this.panelDatos.add(this.txtAutor);

        this.panelDatos.add(this.lbAnio);
        this.panelDatos.add(this.txtAnio);

        this.panelDatos.add(this.lbCosto);
        this.panelDatos.add(this.txtCosto);

        this.panelDatos.add(this.lbNpaginas);
        this.panelDatos.add(this.txtNpaginas);

        this.panelDatos.add(this.lbEdicion);
        this.panelDatos.add(this.txtEdicion);

        this.panelDatos.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        this.panelPrincipal.add(this.panelDatos, BorderLayout.CENTER);

    }

    private void iniciarPanelOpciones() {

        this.panelOpciones = new JPanel();
        this.panelOpciones.setLayout(new GridLayout(3, 1, 5, 5));

        this.brnguardar = new JButton("Guardar");
        this.brnguardar.addActionListener(this);

        this.btnCancelar = new JButton("Cancelar");
        this.btnNuevo = new JButton("Nuevo");

        this.panelOpciones.add(this.btnNuevo);
        this.panelOpciones.add(this.brnguardar);
        this.panelOpciones.add(this.btnCancelar);

        this.panelOpciones.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        this.panelPrincipal.add(this.panelOpciones, BorderLayout.EAST);
    }
    
    private void limpiarCampos(){
        this.txtIdbn.setText(null);
        this.txtAutor.setText(null);
        this.txtTitulo.setText(null);
        this.txtNpaginas.setText("");
        this.txtEdicion.setText(null);
        this.txtAnio.setText("");
        this.txtCosto.setText("0");
        
    }

    private void guardarDatos(){
        try {
            Publicacion c = this.leerDatos();
            this.modelo.insertarPublicacion(c);
            Mensaje.mostrar(this, "Exito", "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
        }catch(ExcepcionArchivo e){
            Mensaje.mostrar(this, "Error", e.getMessage(), JOptionPane.ERROR_MESSAGE);
        
    }

    }

    private Libro leerDatos() {
        int nPaginas = Integer.valueOf(this.txtNpaginas.getText());
        int edicion = Integer.valueOf(this.txtEdicion.getText());
        String idbn = this.txtIdbn.getText();
        String titulo = this.txtTitulo.getText();
        String autor = this.txtAutor.getText();
        int anio = Integer.valueOf(this.txtAnio.getText());
        double costo = Double.valueOf(this.txtCosto.getText());

        return new Libro(nPaginas, edicion, idbn, titulo, autor, anio, costo);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.brnguardar) {
            this.guardarDatos();
            limpiarCampos();
        }

    }

}
