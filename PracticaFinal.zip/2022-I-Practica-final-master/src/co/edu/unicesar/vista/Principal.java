/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicesar.vista;

import co.edu.unicesar.excepciones.ExcepcionArchivo;
import java.awt.HeadlessException;
import javax.swing.JOptionPane;

/**
 *
 * @author JAIRO
 */
public class Principal {

    public static void main(String[] args) throws ExcepcionArchivo {
        new Opcion();


    }
}
