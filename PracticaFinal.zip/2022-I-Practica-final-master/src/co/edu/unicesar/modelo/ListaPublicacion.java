/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.unicesar.modelo;

import co.edu.unicesar.excepciones.ExcepcionArchivo;
import co.edu.unicesar.persistencia.*;
import java.util.List;

/**
 *
 * @author JAIRO
 */
public class ListaPublicacion implements IPublicacionDao {
    
    private IPublicacionDao registroPublicaciones;
    

    public ListaPublicacion(int Op) {
        switch (Op) {
            case 1:
                this.registroPublicaciones = new ArrayListPublicacion();
                break;
            case 2:
                this.registroPublicaciones = new ImpArchivoTexto();
                break;
            case 3:
                this.registroPublicaciones = new ImpArchivoObjeto();
                break;
            default: this.registroPublicaciones = new ImpArchivoTexto();
                break;
        }
    }
    
    
    @Override
    public void insertarPublicacion(Publicacion p) throws ExcepcionArchivo {
        
        this.registroPublicaciones.insertarPublicacion(p);
        
    }

    @Override
    public List<Publicacion> leerPublicaciones() throws ExcepcionArchivo {
        
        return this.registroPublicaciones.leerPublicaciones();
        
    }

    @Override
    public Publicacion buscarPublicacion(Publicacion p) throws ExcepcionArchivo {
        
        return this.registroPublicaciones.buscarPublicacion(p);
        
    }

    @Override
    public Publicacion eliminarPublicacion(Publicacion p) throws ExcepcionArchivo {
        
        return this.registroPublicaciones.eliminarPublicacion(p);
        
    }

    @Override
    public List<Publicacion> filtrar(String idbn) throws ExcepcionArchivo {
        return this.registroPublicaciones.filtrar(idbn);

    }
    
}
